#!/bin/bash
set -euo pipefail

# ROS setup scripts may reference optional vars that are unset under `set -u`.
set +u
source /opt/ros/humble/setup.bash
source ~/source/realsense_ros_ws/install/setup.bash
source ~/source/rtabmap_ws/install/setup.bash
set -u

LOGDIR=~/source_mapping_logs
mkdir -p "$LOGDIR"

ros2 run realsense2_camera realsense2_camera_node --ros-args -p product_line:=L500 > "$LOGDIR/realsense2_camera.log" 2>&1 &
RS_PID=$!

echo "RealSense node started (PID=$RS_PID)"
sleep 4

ros2 launch rtabmap_launch rtabmap.launch.py > "$LOGDIR/rtabmap.launch.log" 2>&1 &
RTAB_PID=$!

echo "RTAB-Map launched (PID=$RTAB_PID)"

echo "Run complete. Logs: $LOGDIR"
