#!/bin/bash
set -euo pipefail

# ROS setup scripts may reference optional vars that are unset under `set -u`.
set +u
source /opt/ros/humble/setup.bash || true
if [ -f ~/source/realsense_ros_ws/install/setup.bash ]; then
  source ~/source/realsense_ros_ws/install/setup.bash
fi
if [ -f ~/source/rtabmap_ws/install/setup.bash ]; then
  source ~/source/rtabmap_ws/install/setup.bash
fi
set -u

echo "=== Component check ==="

# Librealsense
if [ -f "/usr/local/lib/cmake/realsense2/realsense2Config.cmake" ]; then
  RS_LOCAL_VER="$(grep -E 'set\(PACKAGE_VERSION "[0-9]+\.[0-9]+\.[0-9]+"\)' /usr/local/lib/cmake/realsense2/realsense2ConfigVersion.cmake 2>/dev/null | sed -n 's|.*"\([0-9][0-9.]*\)".*|\1|p' | head -n 1)"
  echo "Local librealsense installed (version: ${RS_LOCAL_VER:-unknown})"
else
  echo "Local librealsense missing"
fi

echo "--- RealSense version checks ---"
if command -v rs-enumerate-devices >/dev/null 2>&1; then
  echo "Running: rs-enumerate-devices --version"
  RS_VER="$(rs-enumerate-devices --version 2>/dev/null || true)"
  if [ -n "$RS_VER" ]; then
    echo "$RS_VER"
  else
    echo "librealsense tool version: unable to detect"
  fi
else
  echo "librealsense tool version: rs-enumerate-devices not found"
fi

if ros2 pkg prefix realsense2_camera >/dev/null 2>&1; then
  RS_ROS_VER="$(ros2 pkg xml realsense2_camera 2>/dev/null | sed -n 's|.*<version>\(.*\)</version>.*|\1|p' | head -n 1)"
  if [ -n "$RS_ROS_VER" ]; then
    echo "realsense2_camera package version: $RS_ROS_VER"
  else
    echo "realsense2_camera package version: unable to detect"
  fi
else
  echo "realsense2_camera package version: package not found"
fi

# ROS packages
PKG_LIST="$(ros2 pkg list 2>/dev/null || true)"

get_ros_pkg_version() {
  local pkg="$1"
  ros2 pkg xml "$pkg" 2>/dev/null | sed -n 's|.*<version>\(.*\)</version>.*|\1|p' | head -n 1
}

check_pkg() {
  local pkg="$1"
  if echo "$PKG_LIST" | grep -qx "$pkg"; then
    local pkg_ver
    pkg_ver="$(get_ros_pkg_version "$pkg")"
    if [ -n "$pkg_ver" ]; then
      echo "$pkg installed (version: $pkg_ver)"
    else
      echo "$pkg installed (version: unknown)"
    fi
  else
    echo "$pkg missing"
  fi
}

echo "--- ROS package checks ---"
check_pkg "realsense2_camera"
check_pkg "realsense2_camera_msgs"
check_pkg "rtabmap_ros"
check_pkg "rtabmap_launch"

echo "--- RealSense ROS checks ---"
check_pkg "realsense2_camera"
check_pkg "realsense2_camera_msgs"

echo "--- RealSense source-build verification ---"
errors=0

# apt librealsense/realsense ROS packages should not be installed when using source build.
if dpkg -l 2>/dev/null | grep -qE 'ros-humble-librealsense2|ros-humble-realsense2-camera|ros-humble-realsense2-camera-msgs'; then
  echo "FAIL: apt realsense ROS packages still installed"
  dpkg -l 2>/dev/null | grep -E 'ros-humble-librealsense2|ros-humble-realsense2-camera|ros-humble-realsense2-camera-msgs' || true
  errors=$((errors+1))
else
  echo "PASS: No apt realsense ROS packages installed"
fi

# Ensure realsense2_camera is available after sourcing the workspace.
if echo "$PKG_LIST" | grep -qx "realsense2_camera"; then
  echo "PASS: realsense2_camera package found in workspace"
else
  echo "FAIL: realsense2_camera package not found in workspace"
  errors=$((errors+1))
fi

if [ "$errors" -eq 0 ]; then
  echo "PASS: RealSense source-build verification"
else
  echo "FAIL: RealSense source-build verification ($errors issue(s))"
fi

echo "--- SLAM package checks ---"
check_pkg "rtabmap_slam"
check_pkg "slam_toolbox"

echo "=== Done ==="
