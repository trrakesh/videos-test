#!/bin/bash
set -euo pipefail

WORKDIR=~/source/rtabmap_ws
rm -rf "$WORKDIR"
mkdir -p "$WORKDIR/src"
cd "$WORKDIR/src"

# Download rtabmap core and ROS wrappers zips
RTABMAP_TAG=0.22.1
RTABMAP_ROS_TAG=0.22.1-humble
RTABMAP_ZIP_URL="https://github.com/introlab/rtabmap/archive/refs/tags/${RTABMAP_TAG}.zip"
RTABMAP_ROS_ZIP_URL="https://github.com/introlab/rtabmap_ros/archive/refs/tags/${RTABMAP_ROS_TAG}.zip"

wget -O /tmp/rtabmap-${RTABMAP_TAG}.zip "$RTABMAP_ZIP_URL"
wget -O /tmp/rtabmap_ros-${RTABMAP_ROS_TAG}.zip "$RTABMAP_ROS_ZIP_URL"

unzip -q -o /tmp/rtabmap-${RTABMAP_TAG}.zip -d /tmp
unzip -q -o /tmp/rtabmap_ros-${RTABMAP_ROS_TAG}.zip -d /tmp

rsync -a /tmp/rtabmap-${RTABMAP_TAG}/ rtabmap/
rsync -a /tmp/rtabmap_ros-${RTABMAP_ROS_TAG}/ rtabmap_ros/

cd "$WORKDIR"

# Install ROS deps, skip realsense since we build from source
set +u
rosdep install --from-paths src --ignore-src --rosdistro humble --skip-keys "realsense2 librealsense2 realsense2_camera realsense2_camera_msgs" -y || true
set -u

# Ensure local librealsense is on the path
export CMAKE_PREFIX_PATH=/usr/local:${CMAKE_PREFIX_PATH:-}
export LD_LIBRARY_PATH=/usr/local/lib:${LD_LIBRARY_PATH:-}

set +u
source /opt/ros/humble/setup.bash
# Also overlay realsense_ros workspace if built
if [ -f ~/source/realsense_ros_ws/install/setup.bash ]; then
  source ~/source/realsense_ros_ws/install/setup.bash
fi
set -u

colcon build --symlink-install || { echo "Build failed"; exit 1; }

echo ""
echo "=== Verification ==="
errors=0

set +u
source "$WORKDIR/install/setup.bash" 2>/dev/null || true
set -u

if ros2 pkg list 2>/dev/null | grep -qE 'rtabmap_ros|rtabmap_slam|rtabmap_launch'; then
  echo "PASS: rtabmap_ros packages found in workspace"
  ros2 pkg list 2>/dev/null | grep -E 'rtabmap_ros|rtabmap_slam|rtabmap_launch' || true
else
  echo "FAIL: rtabmap_ros packages not found"
  errors=$((errors+1))
fi

if [ "$errors" -eq 0 ]; then
  echo "Verification passed: RTAB-Map built from source."
else
  echo "Verification failed: $errors issues found."
  exit 2
fi
