#!/bin/bash
set -euo pipefail

WORKDIR=~/source/librealsense
mkdir -p "$WORKDIR"
cd "$WORKDIR"

TAG=v2.54.2
ZIP_URL="https://github.com/IntelRealSense/librealsense/archive/refs/tags/${TAG}.zip"
TMPZIP="/tmp/librealsense-${TAG}.zip"

wget -O "$TMPZIP" "$ZIP_URL"
rm -rf "$WORKDIR"/*

unzip -q -o "$TMPZIP" -d /tmp
extracted="/tmp/librealsense-${TAG#v}"
if [ ! -d "$extracted" ]; then
  extracted="/tmp/librealsense-${TAG#v}" # fallback
fi
rsync -a "$extracted"/ "$WORKDIR/"

mkdir -p "$WORKDIR/build"
cd "$WORKDIR/build"
cmake .. -DBUILD_EXAMPLES=OFF -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)
sudo make install
sudo ldconfig

echo "Installed librealsense from source at $TAG"
