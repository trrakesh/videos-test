#!/bin/bash
set -euo pipefail

# Install base build dependencies for ROS2 + librealsense + rtabmap
sudo apt update
sudo apt install -y \
  build-essential cmake git wget unzip curl \
  python3-pip python3-rosdep python3-colcon-common-extensions python3-vcstool \
  libusb-1.0-0-dev libudev-dev libssl-dev \
  libgtk-3-dev libgl1-mesa-dev libglu1-mesa-dev \
  libxrandr-dev libxi-dev libxinerama-dev libxcursor-dev libxss-dev \
  libopencv-dev libpcl-dev libeigen3-dev libboost-all-dev \
  libsuitesparse-dev libgflags-dev libgoogle-glog-dev libceres-dev \
  qtbase5-dev libqt5svg5-dev \
  python3-rosdep \
  libasio-dev libtinyxml2-dev

# For rtabmap source
sudo apt install -y \
  libopenni2-dev libflann-dev libqhull-dev \
  libjpeg-dev libtiff-dev libpng-dev
# gtsam packages: prefer ROS binary package if libgtsam-dev unavailable
if ! apt-cache show libgtsam-dev >/dev/null 2>&1; then
  sudo apt install -y ros-humble-gtsam
else
  sudo apt install -y libgtsam-dev
fi

sudo rosdep init || true
rosdep update

echo "Build dependencies installed."
