#!/bin/bash

WORKDIR=~/source/realsense_ros_ws
rm -rf "$WORKDIR"
mkdir -p "$WORKDIR/src"
cd "$WORKDIR/src"

TAG=4.54.1
ZIP_URL="https://github.com/realsenseai/realsense-ros/archive/refs/tags/${TAG}.zip"
TMPZIP="/tmp/realsense-ros-${TAG}.zip"
wget -O "$TMPZIP" "$ZIP_URL"
unzip -q -o "$TMPZIP" -d /tmp
EXTRACTED="/tmp/realsense-ros-${TAG}"
if [ ! -d "$EXTRACTED" ]; then
  EXTRACTED="/tmp/realsense-ros-${TAG#v}"
fi
if [ ! -d "$EXTRACTED" ]; then
  echo "Failed to extract realsense-ros zip"
  exit 1
fi
rsync -a "$EXTRACTED"/ .

cd "$WORKDIR"

# Remove apt librealsense packages to avoid conflicting versions
sudo apt remove -y ros-humble-librealsense2 ros-humble-realsense2-camera ros-humble-realsense2-camera-msgs || true
sudo apt autoremove -y || true

rosdep install --from-paths src --ignore-src --rosdistro humble --skip-keys "realsense2 librealsense2" -y || true

# Ensure local librealsense install is found first
if [ -f "/usr/local/lib/cmake/realsense2/realsense2Config.cmake" ]; then
  export CMAKE_PREFIX_PATH=/usr/local:${CMAKE_PREFIX_PATH:-}
  export LD_LIBRARY_PATH=/usr/local/lib:${LD_LIBRARY_PATH:-}
else
  echo "ERROR: local librealsense not found in /usr/local. Build librealsense first."
  exit 1
fi

source /opt/ros/humble/setup.bash
colcon build --symlink-install || { echo "Build failed"; exit 1; }

echo ""
echo "=== Verification ==="
errors=0

# 1) apt librealsense must NOT be installed
if dpkg -l 2>/dev/null | grep -qE 'ros-humble-librealsense2|ros-humble-realsense2-camera'; then
  echo "FAIL: apt realsense packages still installed:"
  dpkg -l | grep -E 'ros-humble-librealsense2|ros-humble-realsense2-camera'
  errors=$((errors+1))
else
  echo "PASS: No apt realsense packages installed"
fi

# 2) local librealsense SDK must exist
if [ -f "/usr/local/lib/cmake/realsense2/realsense2Config.cmake" ]; then
  LOCAL_VER=$(grep 'realsense2_VERSION ' /usr/local/lib/cmake/realsense2/realsense2Config.cmake | grep -oP '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || true)
  echo "PASS: Local librealsense version: ${LOCAL_VER:-unknown}"
else
  echo "FAIL: Local librealsense not found at /usr/local"
  errors=$((errors+1))
fi

# 3) realsense2_camera package must be built in workspace
set +u
source "$WORKDIR/install/setup.bash" 2>/dev/null || true
set -u
if ros2 pkg list 2>/dev/null | grep -q realsense2_camera; then
  echo "PASS: realsense2_camera package found in workspace"
else
  echo "FAIL: realsense2_camera package not found in workspace"
  errors=$((errors+1))
fi

if [ "$errors" -eq 0 ]; then
  echo ""
  echo "Verification passed: realsense_ros built from source using local librealsense."
else
  echo ""
  echo "Verification FAILED: $errors issue(s) found."
  exit 2
fi
