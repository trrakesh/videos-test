#!/bin/bash
set -euo pipefail

# Cleanup old apt ROS/RealSense packages and prior workspaces
sudo apt remove -y \
  ros-humble-librealsense2 \
  ros-humble-realsense2-camera \
  ros-humble-realsense2-camera-msgs \
  ros-humble-rtabmap-ros \
  ros-humble-rtabmap-launch \
  ros-humble-rtabmap-slam \
  ros-humble-rtabmap-viz \
  ros-humble-rtabmap-msgs \
  ros-humble-rtabmap-util \
  ros-humble-rtabmap-sync \
  ros-humble-rtabmap-odom \
  ros-humble-rtabmap-conversions \
  ros-humble-rtabmap-rviz-plugins \
  ros-humble-librealsense2-dbgsym || true

sudo apt autoremove -y || true

echo "Removing old source workspaces..."
rm -rf ~/source/librealsense ~/source/realsense_ros_ws ~/source/rtabmap_ws
rm -rf /home/ubuntu/l515_3d_map_scripts/ros2_ws
rm -rf /home/ubuntu/l515_3d_map_scripts/build /home/ubuntu/l515_3d_map_scripts/logs
rm -rf /home/ubuntu/librealsense /home/ubuntu/realsense-ros
mkdir -p ~/source

echo "Removing local librealsense install artifacts..."
sudo rm -rf /usr/local/bin/realsense-viewer /usr/local/bin/rs-enumerate-devices /usr/local/bin/rs-save-to-disk
sudo rm -rf /usr/local/include/librealsense2 /usr/local/lib/librealsense* /usr/local/lib/cmake/realsense2
sudo rm -rf /usr/local/lib/pkgconfig/librealsense2.pc

echo "Cleanup complete.\nVerifying cleanup..."

# verify cleanup
errors=0
if command -v realsense-viewer >/dev/null 2>&1; then
  echo "ERROR: realsense-viewer still present"
  errors=$((errors+1))
fi

if dpkg -l | grep -E 'ros-humble-librealsense2|ros-humble-realsense2-camera|ros-humble-rtabmap|rtabmap' >/dev/null 2>&1; then
  echo "ERROR: leftover ROS packages found"
  dpkg -l | grep -E 'ros-humble-librealsense2|ros-humble-realsense2-camera|ros-humble-rtabmap|rtabmap'
  errors=$((errors+1))
fi

if [ -d "/usr/local/include/librealsense2" ] || [ -d "/usr/local/lib/cmake/realsense2" ] || ls /usr/local/lib/librealsense* >/dev/null 2>&1; then
  echo "ERROR: local librealsense artifacts remain"
  errors=$((errors+1))
fi

if [ -d "/home/ubuntu/l515_3d_map_scripts/ros2_ws" ] || [ -d "/home/ubuntu/l515_3d_map_scripts/build" ] || [ -d "/home/ubuntu/l515_3d_map_scripts/logs" ]; then
  echo "ERROR: build/workspace directories still present"
  errors=$((errors+1))
fi

if [ "$errors" -eq 0 ]; then
  echo "Verification passed: everything removed."
else
  echo "Verification failed: $errors issues found."
  exit 2
fi
